from flask import Flask, render_template, jsonify, send_file, request
import os
import json
import requests
from datetime import datetime
import time
import re
import zipfile
from io import BytesIO
from urllib.parse import urljoin, unquote, quote
import logging
import base64
from bs4 import BeautifulSoup
import urllib3

# Отключаем предупреждения о SSL
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DATA_FILE = 'qarmet_procurements.json'
BASE_URL = "https://qpartners.kz"
API_BASE_URL = "https://api.qpartners.kz"

# Создаем сессию
session = requests.Session()
session.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'ru-RU,ru;q=0.9,en;q=0.8',
    'Referer': 'https://qpartners.kz/',
    'Origin': 'https://qpartners.kz',
})
session.verify = False

# ОБНОВЛЕННЫЕ КУКИ
COOKIES = {
    'i18n_redirected': 'ru',
    '_ga': 'GA1.1.1512509498.1758280468',
    'auth': '%7B%22authenticated%22%3Atrue%2C%22profile%22%3A%7B%22id%22%3A4613%2C%22first_name%22%3A%224321%22%2C%22middle_name%22%3A%22321321%22%2C%22last_name%22%3A%22321321%22%2C%22identifier%22%3A%22%22%2C%22email%22%3A%22tegati7116%40okcdeals.com%22%2C%22phone%22%3A%22123321321%22%2C%22created_at%22%3A%2220.11.2025%22%2C%22permissions%22%3A%5B%7B%22id%22%3A3870%2C%22name%22%3A%22Ameriabank%20CJSC%22%2C%22roles%22%3A%5B%7B%22id%22%3A3%2C%22code%22%3A%22admin%22%2C%22name%22%3A%22%D0%90%D0%B4%D0%BC%D0%B8%D0%BD%D0%B8%D1%81%D1%82%D1%80%D0%B0%D1%82%D0%BE%D1%80%20%D0%BA%D0%BE%D0%BC%D0%BF%D0%B0%D0%BD%D0%B8%D0%B8%22%7D%2C%7B%22id%22%3A4%2C%22code%22%3A%22employee%22%2C%22name%22%3A%22%D0%A1%D0%BE%D1%82%D1%80%D1%83%D0%B4%D0%BD%D0%B8%D0%BA%22%7D%2C%7B%22id%22%3A5%2C%22code%22%3A%22supplier%22%2C%22name%22%3A%22%D0%9F%D0%BE%D1%81%D1%82%D0%B0%D0%B2%D1%89%D0%B8%D0%BA%22%7D%5D%7D%5D%2C%22roles%22%3A%5B%7B%22id%22%3A1%2C%22code%22%3A%22user%22%2C%22name%22%3A%22%D0%9F%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%22%7D%5D%2C%22links%22%3A%5B%5D%2C%22userCompany%22%3A%7B%22id%22%3A4681%2C%22sys_companies_units_id%22%3Anull%2C%22sys_companies_id%22%3A3870%2C%22sys_users_id%22%3A4613%2C%22position%22%3Anull%2C%22created_at%22%3A%222025-11-20T10%3A47%3A28.000000Z%22%2C%22updated_at%22%3A%222025-11-20T10%3A47%3A28.000000Z%22%2C%22deleted_at%22%3Anull%2C%22is_active%22%3A1%7D%7D%2C%22company%22%3A%7B%22id%22%3A3870%2C%22name%22%3A%22Ameriabank%20CJSC%22%2C%22identifier%22%3A%22240140012345%22%2C%22country%22%3A%22%D0%90%D0%92%D0%A1%D0%A2%D0%A0%D0%98%D0%AF%22%2C%22created_at%22%3A%2220.11.2025%22%2C%22is_customer%22%3Afalse%2C%22is_supplier%22%3Atrue%7D%2C%22token%22%3A%22231330%7CdAJ3kIZ2zCnYTP2BSACngyMjie03YGszXzdBjnhW%22%7D',
    '_ga_WCLLT03GTJ': 'GS2.1.s1763707301$o45$g1$t1763707331$j30$l0$h0'
}

class QarmetParser:
    def __init__(self):
        self.setup_session()
    
    def setup_session(self):
        """Настраиваем сессию с авторизацией"""
        try:
            for name, value in COOKIES.items():
                session.cookies.set(name, value, domain='.qpartners.kz')
            logger.info("✅ Сессия настроена с ОБНОВЛЕННЫМИ куками")
            
            # Проверяем авторизацию
            test_url = f"{API_BASE_URL}/api/public/trade/buys?page=1&per_page=1"
            response = session.get(test_url, timeout=10)
            if response.status_code == 200:
                logger.info("✅ Авторизация успешна")
            else:
                logger.error(f"❌ Ошибка авторизации: {response.status_code}")
                
        except Exception as e:
            logger.error(f"❌ Ошибка настройки сессии: {e}")
    
    def fetch_all_procurements(self):
        """Получаем ВСЕ закупки через API"""
        logger.info("🚀 Загружаем все закупки...")
        
        all_procurements = []
        page = 1
        
        while True:
            try:
                url = f"{API_BASE_URL}/api/public/trade/buys"
                params = {"page": page, "per_page": 50}
                
                logger.info(f"📄 Страница {page}...")
                response = session.get(url, params=params, timeout=30)
                
                if response.status_code != 200:
                    logger.error(f"❌ Ошибка {response.status_code}")
                    break
                
                data = response.json()
                if not data or 'data' not in data or not data['data']:
                    logger.info("📭 Данные закончились")
                    break
                
                items = data['data']
                logger.info(f"✅ Страница {page}: {len(items)} закупок")
                
                for item in items:
                    procurement = self.process_procurement_item(item)
                    if procurement:
                        all_procurements.append(procurement)
                        # Небольшая задержка между запросами
                        time.sleep(0.2)
                
                page += 1
                time.sleep(0.5)
                
            except Exception as e:
                logger.error(f"❌ Ошибка страницы {page}: {e}")
                break
        
        logger.info(f"🎉 Всего закупок: {len(all_procurements)}")
        return all_procurements
    
    def process_procurement_item(self, item):
        """Обрабатываем одну закупку и находим ВСЕ реальные файлы"""
        try:
            trade_id = item.get('id', '')
            logger.info(f"🔍 Обрабатываем закупку {trade_id}")
            
            # Парсим страницу закупки для поиска реальных файлов
            documents = self.parse_procurement_page(trade_id)
            
            procurement = {
                "id": str(trade_id),
                "number": item.get("code", ""),
                "title": item.get("name", ""),
                "amount": item.get("amount", ""),
                "method": item.get("method", {}).get("name", "") if isinstance(item.get("method"), dict) else "",
                "start_date": self.parse_date(item.get("start_date", "")),
                "end_date": self.parse_date(item.get("end_date", "")),
                "status": item.get("status", {}).get("name", "") if isinstance(item.get("status"), dict) else "",
                "link": f"{BASE_URL}/public/buys/show/{trade_id}",
                "organizer": "АО QARMET",
                "category": "Прочее", 
                "description": item.get("description", ""),
                "documents": documents,
                "raw_amount": self.extract_numeric_amount(item.get("amount", "")),
                "files_count": len(documents)
            }
            
            logger.info(f"✅ Закупка {trade_id}: {len(documents)} файлов")
            return procurement
            
        except Exception as e:
            logger.error(f"❌ Ошибка обработки закупки: {e}")
            return None
    
    def parse_procurement_page(self, trade_id):
        """Парсим страницу закупки и находим ВСЕ реальные файлы"""
        documents = []
        
        try:
            url = f"{BASE_URL}/public/buys/show/{trade_id}"
            logger.info(f"🌐 Парсим страницу: {trade_id}")
            
            response = session.get(url, timeout=15)
            if response.status_code != 200:
                logger.error(f"❌ Не удалось загрузить страницу: {response.status_code}")
                return documents
            
            # Сохраняем HTML для отладки
            with open(f"debug_{trade_id}.html", "w", encoding="utf-8") as f:
                f.write(response.text)
            logger.info(f"💾 HTML сохранен: debug_{trade_id}.html")
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # 1. Ищем ВСЕ ссылки с файлами
            all_links = soup.find_all('a', href=True)
            logger.info(f"🔗 Найдено ссылок: {len(all_links)}")
            
            for link in all_links:
                href = link.get('href', '')
                if self.is_real_file_link(href):
                    doc = self.create_document_from_link(link, href, trade_id)
                    if doc and not self.is_duplicate_document(doc, documents):
                        documents.append(doc)
                        logger.info(f"✅ Найден файл в ссылке: {doc['name']}")
            
            # 2. Ищем файлы в data-атрибутах
            data_elements = soup.find_all(attrs={
                "data-url": True, 
                "data-file": True, 
                "data-src": True,
                "data-href": True
            })
            logger.info(f"🔗 Найдено data-элементов: {len(data_elements)}")
            
            for elem in data_elements:
                for attr in ["data-url", "data-file", "data-src", "data-href"]:
                    data_url = elem.get(attr)
                    if data_url and self.is_real_file_link(data_url):
                        doc = self.create_document_from_data(elem, data_url, trade_id, attr)
                        if doc and not self.is_duplicate_document(doc, documents):
                            documents.append(doc)
                            logger.info(f"✅ Найден файл в {attr}: {doc['name']}")
            
            # 3. Ищем в JavaScript коде
            scripts = soup.find_all('script')
            logger.info(f"🔗 Найдено скриптов: {len(scripts)}")
            
            for script in scripts:
                if script.string:
                    # Ищем прямые ссылки на файлы в JS
                    file_patterns = [
                        r'["\'](https?://[^"\']*\.pdf[^"\']*)["\']',
                        r'["\'](https?://[^"\']*\.doc[^"\']*)["\']',
                        r'["\'](https?://[^"\']*\.docx[^"\']*)["\']',
                        r'["\'](https?://[^"\']*\.xls[^"\']*)["\']',
                        r'["\'](https?://[^"\']*\.xlsx[^"\']*)["\']',
                        r'["\'](https?://[^"\']*\.zip[^"\']*)["\']',
                        r'fileUrl\s*:\s*["\']([^"\']+)["\']',
                        r'downloadUrl\s*:\s*["\']([^"\']+)["\']',
                        r'url\s*:\s*["\']([^"\']*\.(pdf|doc|docx|xls|xlsx|zip))["\']'
                    ]
                    
                    for pattern in file_patterns:
                        matches = re.findall(pattern, script.string, re.IGNORECASE)
                        for match in matches:
                            file_url = match[0] if isinstance(match, tuple) else match
                            if self.is_real_file_link(file_url):
                                doc = self.create_document_from_url(file_url, f"file_{trade_id}", trade_id)
                                if doc and not self.is_duplicate_document(doc, documents):
                                    documents.append(doc)
                                    logger.info(f"✅ Найден файл в JS: {doc['name']}")
            
            # 4. Пробуем найти API endpoints для файлов
            api_docs = self.search_api_files(trade_id)
            documents.extend(api_docs)
            
            # 5. Верифицируем файлы - проверяем что они реально существуют
            verified_docs = []
            for doc in documents:
                if self.verify_document(doc['url']):
                    verified_docs.append(doc)
                    logger.info(f"✅ Файл верифицирован: {doc['name']}")
                else:
                    logger.warning(f"⚠️ Файл недоступен: {doc['name']}")
            
            logger.info(f"📊 Итоговое количество файлов: {len(verified_docs)}/{len(documents)}")
            return verified_docs
            
        except Exception as e:
            logger.error(f"❌ Ошибка парсинга {trade_id}: {e}")
            return documents
    
    def search_api_files(self, trade_id):
        """Ищем файлы через API endpoints"""
        documents = []
        
        api_endpoints = [
            f"{API_BASE_URL}/api/files/trade/{trade_id}",
            f"{API_BASE_URL}/api/documents/procurement/{trade_id}",
            f"{API_BASE_URL}/api/public/trade/{trade_id}/files",
            f"{API_BASE_URL}/api/public/buys/{trade_id}/documents",
        ]
        
        for endpoint in api_endpoints:
            try:
                logger.info(f"🔍 Проверяем API: {endpoint}")
                response = session.get(endpoint, timeout=10)
                
                if response.status_code == 200:
                    # Пробуем парсить JSON
                    try:
                        data = response.json()
                        if isinstance(data, list):
                            for item in data:
                                if 'url' in item or 'file_url' in item or 'document_url' in item:
                                    url = item.get('url') or item.get('file_url') or item.get('document_url')
                                    name = item.get('name') or item.get('filename') or f"api_document_{trade_id}"
                                    doc = self.create_document_from_url(url, name, trade_id)
                                    if doc and not self.is_duplicate_document(doc, documents):
                                        documents.append(doc)
                                        logger.info(f"✅ Найден файл через API: {doc['name']}")
                    except:
                        # Если не JSON, пробуем найти ссылки в тексте
                        file_urls = re.findall(r'https?://[^\s<>"]+\.(pdf|doc|docx|xls|xlsx|zip)', response.text, re.IGNORECASE)
                        for url in file_urls:
                            doc = self.create_document_from_url(url, f"api_file_{trade_id}", trade_id)
                            if doc and not self.is_duplicate_document(doc, documents):
                                documents.append(doc)
            except Exception as e:
                logger.error(f"❌ Ошибка API {endpoint}: {e}")
        
        return documents
    
    def is_real_file_link(self, url):
        """Проверяем что ссылка ведет на реальный файл"""
        if not url or url.startswith(('javascript:', 'mailto:', '#')):
            return False
        
        url_lower = url.lower()
        
        # Расширения файлов
        file_extensions = ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.zip', '.rar', '.jpg', '.jpeg', '.png']
        
        # Ключевые слова в URL
        file_keywords = ['download', 'file', 'document', 'attachment', 'doc', 'attach']
        
        # Проверяем расширения
        if any(url_lower.endswith(ext) for ext in file_extensions):
            return True
        
        # Проверяем расширения с параметрами
        if any(f'.{ext}?' in url_lower for ext in ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'zip', 'rar']):
            return True
        
        # Проверяем ключевые слова
        if any(keyword in url_lower for keyword in file_keywords):
            return True
        
        # Проверяем API endpoints файлов
        if any(pattern in url_lower for pattern in ['/api/files/', '/storage/', '/cdn/', '/uploads/']):
            return True
        
        return False
    
    def create_document_from_link(self, link, href, trade_id):
        """Создаем документ из ссылки"""
        try:
            # Получаем имя файла
            name = link.get_text(strip=True)
            if not name or len(name) < 2:
                # Пробуем извлечь из URL
                filename = href.split('/')[-1].split('?')[0]
                name = unquote(filename) if filename else f"document_{trade_id}"
            
            # Создаем полный URL
            full_url = href if href.startswith('http') else urljoin(BASE_URL, href)
            
            # Очищаем имя
            clean_name = self.clean_filename(name)
            
            return {
                'id': f"doc_{hash(full_url) & 0xFFFFFFFF}",
                'name': clean_name,
                'url': full_url,
                'download_url': full_url,
                'type': self.get_file_type(clean_name),
                'icon': self.get_file_icon(clean_name),
                'size': '',
                'source': 'link',
                'verified': True
            }
        except Exception as e:
            logger.error(f"❌ Ошибка создания документа: {e}")
            return None
    
    def create_document_from_data(self, element, data_url, trade_id, attr_name):
        """Создаем документ из data-атрибута"""
        try:
            name = element.get_text(strip=True) or f"document_{trade_id}"
            full_url = data_url if data_url.startswith('http') else urljoin(BASE_URL, data_url)
            clean_name = self.clean_filename(name)
            
            return {
                'id': f"data_{hash(full_url) & 0xFFFFFFFF}",
                'name': clean_name,
                'url': full_url,
                'download_url': full_url,
                'type': self.get_file_type(clean_name),
                'icon': self.get_file_icon(clean_name),
                'size': '',
                'source': f'data_{attr_name}',
                'verified': True
            }
        except Exception as e:
            logger.error(f"❌ Ошибка создания data-документа: {e}")
            return None
    
    def create_document_from_url(self, url, name, trade_id):
        """Создаем документ из URL"""
        try:
            full_url = url if url.startswith('http') else urljoin(BASE_URL, url)
            
            # Извлекаем имя файла из URL если нужно
            if 'file_' in name:
                filename = full_url.split('/')[-1].split('?')[0]
                if '.' in filename:
                    name = unquote(filename)
            
            clean_name = self.clean_filename(name)
            
            return {
                'id': f"url_{hash(full_url) & 0xFFFFFFFF}",
                'name': clean_name,
                'url': full_url,
                'download_url': full_url,
                'type': self.get_file_type(clean_name),
                'icon': self.get_file_icon(clean_name),
                'size': '',
                'source': 'url',
                'verified': True
            }
        except Exception as e:
            logger.error(f"❌ Ошибка создания URL-документа: {e}")
            return None
    
    def verify_document(self, url):
        """Проверяем что файл действительно существует"""
        try:
            response = session.head(url, timeout=10, allow_redirects=True)
            if response.status_code == 200:
                # Проверяем content-type
                content_type = response.headers.get('content-type', '').lower()
                if 'text/html' in content_type and 'attachment' not in response.headers.get('content-disposition', '').lower():
                    return False  # Это HTML страница, а не файл
                return True
            return False
        except:
            return False
    
    def is_duplicate_document(self, new_doc, existing_docs):
        """Проверяем дубликаты документов"""
        return any(doc['url'] == new_doc['url'] for doc in existing_docs)
    
    def clean_filename(self, filename):
        """Очищаем имя файла"""
        if not filename:
            return "document"
        cleaned = re.sub(r'[<>:"/\\|?*]', '_', filename)
        if len(cleaned) > 100:
            name, ext = os.path.splitext(cleaned)
            cleaned = name[:100-len(ext)] + ext
        return cleaned
    
    def get_file_type(self, filename):
        """Определяем тип файла"""
        ext = filename.split('.')[-1].lower() if '.' in filename else ''
        type_map = {
            'pdf': 'PDF', 'doc': 'Word', 'docx': 'Word',
            'xls': 'Excel', 'xlsx': 'Excel', 'zip': 'Archive',
            'rar': 'Archive', 'jpg': 'Image', 'jpeg': 'Image',
            'png': 'Image'
        }
        return type_map.get(ext, 'File')
    
    def get_file_icon(self, filename):
        """Определяем иконку файла"""
        ext = filename.split('.')[-1].lower() if '.' in filename else ''
        icon_map = {
            'pdf': 'file-pdf', 'doc': 'file-word', 'docx': 'file-word',
            'xls': 'file-excel', 'xlsx': 'file-excel', 'zip': 'file-archive',
            'rar': 'file-archive', 'jpg': 'file-image', 'jpeg': 'file-image',
            'png': 'file-image'
        }
        return icon_map.get(ext, 'file')
    
    def parse_date(self, date_string):
        """Парсим дату"""
        if not date_string:
            return ""
        try:
            if 'T' in date_string:
                return date_string.split('T')[0]
            return date_string.split(' ')[0]
        except:
            return date_string
    
    def extract_numeric_amount(self, amount_str):
        """Извлекаем числовое значение суммы"""
        if not amount_str:
            return 0.0
        try:
            clean_str = re.sub(r'[^\d,.]', '', str(amount_str))
            if not clean_str:
                return 0.0
            if ',' in clean_str and '.' in clean_str:
                if clean_str.rfind(',') > clean_str.rfind('.'):
                    clean_str = clean_str.replace('.', '').replace(',', '.')
                else:
                    clean_str = clean_str.replace(',', '')
            elif ',' in clean_str:
                clean_str = clean_str.replace(',', '.')
            return float(clean_str)
        except:
            return 0.0

    def download_document(self, url, filename):
        """Скачиваем файл"""
        try:
            logger.info(f"📥 Скачиваем: {filename}")
            headers = {
                'Referer': f'{BASE_URL}/public/buys/show/',
                'Accept': 'application/octet-stream, */*'
            }
            response = session.get(url, timeout=30, stream=True, headers=headers)
            
            if response.status_code == 200:
                content = response.content
                # Проверяем что это не HTML страница
                if len(content) > 100 and not content.startswith(b'<!DOCTYPE') and not content.startswith(b'<html'):
                    logger.info(f"✅ Успешно: {filename} ({len(content)} bytes)")
                    return content
                else:
                    logger.warning(f"⚠️ Получен HTML вместо файла: {filename}")
                    return None
            else:
                logger.error(f"❌ Ошибка {response.status_code}: {filename}")
                return None
                
        except Exception as e:
            logger.error(f"❌ Ошибка скачивания {filename}: {e}")
            return None

# Инициализируем парсер
parser = QarmetParser()

def save_data(data):
    """Сохраняем данные в файл"""
    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        logger.info(f"💾 Данные сохранены: {len(data)} записей")
        return True
    except Exception as e:
        logger.error(f"❌ Ошибка сохранения: {e}")
        return False

def load_data():
    """Загружаем данные из файла"""
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                logger.info(f"📂 Данные загружены: {len(data)} записей")
                return data
        except Exception as e:
            logger.error(f"❌ Ошибка загрузки: {e}")
    return []

# ========== РОУТЫ ==========
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/procurements')
def get_procurements():
    data = load_data()
    return jsonify({
        "success": True,
        "count": len(data),
        "procurements": data
    })

@app.route('/refresh')
def refresh_data():
    """Обновляем данные"""
    try:
        logger.info("🔄 Обновляем данные...")
        data = parser.fetch_all_procurements()
        
        if data:
            save_data(data)
            return jsonify({
                "success": True,
                "message": f"Обновлено: {len(data)} закупок",
                "count": len(data)
            })
        else:
            return jsonify({
                "success": False,
                "error": "Не удалось загрузить данные"
            })
            
    except Exception as e:
        logger.error(f"❌ Ошибка обновления: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        })

@app.route('/download/<trade_id>')
def download_procurement_files(trade_id):
    """Скачиваем все файлы закупки"""
    try:
        # Находим закупку в кэше
        data = load_data()
        procurement = next((p for p in data if p['id'] == trade_id), None)
        
        if not procurement:
            return jsonify({"success": False, "error": "Закупка не найдена"})
        
        documents = procurement.get('documents', [])
        if not documents:
            return jsonify({"success": False, "error": "Файлы не найдены"})
        
        # Скачиваем файлы
        zip_buffer = BytesIO()
        downloaded_count = 0
        
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            for doc in documents:
                content = parser.download_document(doc['url'], doc['name'])
                if content:
                    zip_file.writestr(doc['name'], content)
                    downloaded_count += 1
                    logger.info(f"✅ Добавлен в архив: {doc['name']}")
        
        if downloaded_count == 0:
            return jsonify({"success": False, "error": "Не удалось скачать файлы"})
        
        zip_buffer.seek(0)
        filename = f"qarmet_{trade_id}_{downloaded_count}files.zip"
        
        return send_file(
            zip_buffer,
            as_attachment=True,
            download_name=filename,
            mimetype='application/zip'
        )
        
    except Exception as e:
        logger.error(f"❌ Ошибка скачивания: {e}")
        return jsonify({"success": False, "error": str(e)})

@app.route('/api/procurement/<trade_id>')
def get_procurement_detail(trade_id):
    """Получаем детальную информацию по закупке"""
    try:
        data = load_data()
        procurement = next((p for p in data if p['id'] == trade_id), None)
        
        if procurement:
            return jsonify({
                "success": True,
                "procurement": procurement
            })
        else:
            return jsonify({
                "success": False,
                "error": "Закупка не найдена"
            })
            
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route('/debug/<trade_id>')
def debug_procurement(trade_id):
    """Отладочная информация по закупке"""
    try:
        documents = parser.parse_procurement_page(trade_id)
        
        return jsonify({
            "trade_id": trade_id,
            "documents_count": len(documents),
            "documents": documents
        })
        
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/test-auth')
def test_auth():
    """Тестируем авторизацию"""
    try:
        test_url = f"{API_BASE_URL}/api/public/trade/buys?page=1&per_page=1"
        response = session.get(test_url, timeout=10)
        
        return jsonify({
            "status_code": response.status_code,
            "authenticated": response.status_code == 200,
            "response_length": len(response.text) if response.status_code == 200 else 0
        })
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    # Создаем папки и файлы если нужно
    if not os.path.exists('templates'):
        os.makedirs('templates')
    
    # Создаем простой HTML шаблон
    if not os.path.exists('templates/index.html'):
        html_template = """
<!DOCTYPE html>
<html>
<head>
    <title>Qarmet Закупки</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .procurement-card { margin-bottom: 20px; }
        .document-item { 
            border: 1px solid #ddd; 
            padding: 10px; 
            margin: 5px 0; 
            border-radius: 5px;
        }
        .file-icon { margin-right: 8px; }
        .stats { background: #f8f9fa; padding: 10px; border-radius: 5px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1 class="mb-4">🗂️ Qarmet - Реестр закупок (ОБНОВЛЕННЫЕ КУКИ)</h1>
        
        <div class="stats">
            <button class="btn btn-primary" onclick="loadProcurements()">
                <i class="fas fa-sync"></i> Загрузить данные
            </button>
            <button class="btn btn-success" onclick="refreshData()">
                <i class="fas fa-redo"></i> Обновить данные
            </button>
            <button class="btn btn-info" onclick="testAuth()">
                <i class="fas fa-key"></i> Проверить авторизацию
            </button>
            <span id="stats" class="ms-3"></span>
        </div>
        
        <div id="loading" class="alert alert-info" style="display:none;">
            <i class="fas fa-spinner fa-spin"></i> Загрузка...
        </div>
        
        <div id="procurements-list"></div>
    </div>

    <script>
        function loadProcurements() {
            showLoading(true);
            fetch('/api/procurements')
                .then(response => response.json())
                .then(data => {
                    showLoading(false);
                    if (data.success) {
                        displayProcurements(data.procurements);
                        document.getElementById('stats').innerHTML = 
                            `<strong>Закупок:</strong> ${data.count} | 
                             <strong>Всего файлов:</strong> ${data.procurements.reduce((sum, p) => sum + p.files_count, 0)}`;
                    } else {
                        alert('Ошибка загрузки данных');
                    }
                });
        }

        function refreshData() {
            showLoading(true);
            fetch('/refresh')
                .then(response => response.json())
                .then(data => {
                    showLoading(false);
                    if (data.success) {
                        alert('Данные обновлены: ' + data.message);
                        loadProcurements();
                    } else {
                        alert('Ошибка обновления: ' + data.error);
                    }
                });
        }

        function testAuth() {
            fetch('/test-auth')
                .then(response => response.json())
                .then(data => {
                    if (data.authenticated) {
                        alert('✅ Авторизация успешна!');
                    } else {
                        alert('❌ Ошибка авторизации: ' + data.status_code);
                    }
                });
        }

        function displayProcurements(procurements) {
            const container = document.getElementById('procurements-list');
            
            if (procurements.length === 0) {
                container.innerHTML = '<div class="alert alert-warning">Нет данных</div>';
                return;
            }

            container.innerHTML = procurements.map(procurement => `
                <div class="card procurement-card">
                    <div class="card-header">
                        <h5>${procurement.number} - ${procurement.title}</h5>
                        <div class="text-muted small">
                            Статус: ${procurement.status} | 
                            Сумма: ${procurement.amount} | 
                            Дата: ${procurement.start_date} - ${procurement.end_date} |
                            Файлов: <strong>${procurement.files_count}</strong>
                        </div>
                    </div>
                    <div class="card-body">
                        <p>${procurement.description || 'Описание отсутствует'}</p>
                        
                        <div class="documents mt-3">
                            <h6>📎 Документы (${procurement.documents.length}):</h6>
                            ${procurement.documents.length > 0 ? 
                                procurement.documents.map(doc => `
                                    <div class="document-item">
                                        <i class="fas fa-${doc.icon} file-icon"></i>
                                        <strong>${doc.name}</strong>
                                        <small class="text-muted">(${doc.type}) - ${doc.source}</small>
                                        <div class="mt-2">
                                            <a href="${doc.url}" target="_blank" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-external-link-alt"></i> Открыть
                                            </a>
                                            <button onclick="downloadProcurement('${procurement.id}')" class="btn btn-sm btn-success">
                                                <i class="fas fa-download"></i> Скачать все
                                            </button>
                                            <button onclick="debugProcurement('${procurement.id}')" class="btn btn-sm btn-warning">
                                                <i class="fas fa-bug"></i> Отладка
                                            </button>
                                        </div>
                                    </div>
                                `).join('') :
                                '<div class="text-muted">Нет файлов</div>'
                            }
                        </div>
                        
                        <div class="mt-3">
                            <a href="${procurement.link}" target="_blank" class="btn btn-sm btn-info">
                                <i class="fas fa-external-link-alt"></i> Открыть на сайте
                            </a>
                        </div>
                    </div>
                </div>
            `).join('');
        }

        function downloadProcurement(tradeId) {
            window.open('/download/' + tradeId, '_blank');
        }

        function debugProcurement(tradeId) {
            fetch('/debug/' + tradeId)
                .then(response => response.json())
                .then(data => {
                    console.log('Отладка:', data);
                    alert('Найдено файлов: ' + data.documents_count);
                });
        }

        function showLoading(show) {
            document.getElementById('loading').style.display = show ? 'block' : 'none';
        }

        // Автозагрузка при открытии страницы
        document.addEventListener('DOMContentLoaded', loadProcurements);
    </script>
</body>
</html>
        """
        with open('templates/index.html', 'w', encoding='utf-8') as f:
            f.write(html_template)
        print("📄 HTML шаблон создан")

    # Загружаем данные если нет кэша
    if not os.path.exists(DATA_FILE):
        print("🔄 Загружаем данные...")
        data = parser.fetch_all_procurements()
        if data:
            save_data(data)
            print(f"✅ Данные сохранены: {len(data)} закупок")
        else:
            print("❌ Не удалось загрузить данные")

    port = int(os.environ.get('PORT', 5001))
    print(f"🚀 Сервер запущен: http://localhost:{port}")
    print(f"📊 Статистика: http://localhost:{port}/")
    print(f"🔍 Отладка: http://localhost:{port}/debug/10404")
    print(f"🔐 Проверка авторизации: http://localhost:{port}/test-auth")
    print(f"📥 Скачать: http://localhost:{port}/download/10404")
    
    app.run(debug=True, host='0.0.0.0', port=port)